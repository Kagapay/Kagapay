# Kagapay
Kagapay is a multi-wallet app supporting NGN, USD, GBP, EUR, and BTC with live exchange and a 1% fee.